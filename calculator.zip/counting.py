# initialize string
text_string = "I love the ZURI team lectures. "
print("The word to be counted is " + "'I love the ZURI team lectures. '")
result = len(text_string.split())
print("There are " + str(result) + " words. ")
