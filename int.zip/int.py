# adding integers
# creating variables
x = int(input("What's x? "))
y = int(input("What's y? "))
print("The addition is "+ str(x + y))
